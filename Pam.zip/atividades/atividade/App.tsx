import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { Botao } from './src/Botao';

export default function App() {
  return (
      <View>
        <Botao/>
      </View>
  )
}
