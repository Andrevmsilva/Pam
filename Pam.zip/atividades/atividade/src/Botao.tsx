import React, {useState} from 'react';
import { Pressable, View, Text, TextInput } from 'react-native';
import { TextInputmmeu } from './TextInputmmeu';
import { styles } from './Botaostyle';

import * as Clipboard from 'expo-clipboard';



export function Botao() {

    const [pass,setPass] = useState('')
    
   

    function copiartexto(){
        Clipboard.setStringAsync(pass)
      
    }


  return (
<>
      <TextInputmmeu pass = {pass} setPass={setPass}/>

    <Pressable
     onPress={copiartexto}

       style={styles.button}    
    >
      <Text style={styles.texto}>Copiar</Text>
    </Pressable>
    </>

  );
}