import React from 'react';
import { TextInput, View } from 'react-native';

import { styles } from './TextInputStyles';

interface TextInputmmeuProps{
    pass: string;
    setPass: (value:string) => void;
}

export function TextInputmmeu( {pass,setPass}:TextInputmmeuProps) {
  return (

    <TextInput
    style={styles.inputer}
     placeholder='Pass'
     value={pass}
     onChangeText={setPass}
    />

  );
}