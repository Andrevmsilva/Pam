import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  // container:{
  //   alignItems:'center'
  // },
  title: {
    textAlign:'center',
    fontWeight: 'bold',
    fontSize:30,
    color:'#e5bf3c'
  }
});
