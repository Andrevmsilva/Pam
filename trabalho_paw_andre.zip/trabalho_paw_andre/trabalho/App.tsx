import { useState } from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import clark from './assets/pictures/clark kent.png';
import superman from './assets/pictures/file.png';


export default function App() {
  
  const [isActive,setisActive] = useState(false);

  function handleSymbol(){
    setisActive((oldValue : boolean)=>{
      return !oldValue;
    })
  }

  return (
    <View style={isActive ? styles.container1 : styles.container2}>
      <TouchableOpacity onPress={handleSymbol}>
      <Image source={isActive ? superman : clark}></Image>
      </TouchableOpacity>
    </View>
  );
}



const styles = StyleSheet.create({
  container1: {
    flex: 1,
    backgroundColor: '#FF0000',
    alignItems: 'center',
    justifyContent: 'center',
    
  },

  container2: {
    flex: 1,
    backgroundColor: '#0000FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
