import React, {useState} from 'react';
import { Pressable, View, Text, TextInput } from 'react-native';
import { TextInputmmeu } from './TextInputmmeu';
import atualizar from '../passwordService';
import { styles } from './Botaostyle';

import * as Clipboard from 'expo-clipboard';
import generatePass from '../passwordService';


export function Botao() {

    const [pass,setPass] = useState('')
    
    function gerar(){
      let gerasenha = atualizar()
      setPass (gerasenha)
    
  }

    function copiartexto(){
        Clipboard.setStringAsync(pass)
      
    }


  return (
<>
      <TextInputmmeu pass = {gerar}/>

    <Pressable
     onPress={copiartexto}

       style={styles.button}    
    >
      <Text style={styles.texto}>Copiar</Text>
    </Pressable>
    </>

  );
}