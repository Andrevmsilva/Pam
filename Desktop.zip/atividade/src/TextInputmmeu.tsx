import React from 'react';
import { TextInput, View } from 'react-native';

import { styles } from './TextInputStyles';

interface TextInputmmeuProps{
    pass: string
}

export function TextInputmmeu(props: TextInputmmeuProps) {
  return (

    <TextInput
    style={styles.inputer}
     placeholder='Pass'
     value={props.pass}
    />

  );
}